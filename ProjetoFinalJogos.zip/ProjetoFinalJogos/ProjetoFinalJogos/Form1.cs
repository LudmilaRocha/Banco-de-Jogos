
using DocumentFormat.OpenXml.Drawing.Diagrams;
using MySqlConnector;

namespace ProjetoFinalJogos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var connString = "Server=localhost;Database= jogos;Uid=root;Password = root";
            var connection = new MySqlConnection(connString);
            var command = connection.CreateCommand();
            try
            {
                connection.Open();
                command.CommandText = "SELECT nome, ano from CadastroJogos";
                var it = command.ExecuteReader();
                String nome, ano, result = "NOME | ANO\n";
                while (it.Read())
                {
                    nome = it.GetString("nome");
                    result += nome + "|";
                    ano = it.GetString("ano");
                    result += ano + "\n";

                }
                MessageBox.Show(result);
            }
            catch (Exception ex)
            {
                MessageBox.Show("N�o foi poss�vel estabelecer conex�o.\n" + ex.Message);
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                    connection.Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 Form2 = new Form2();
            Form2.Show();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var connString = "Server = localhost;Database=jogos;Uid=root;Password=root";
            var connection = new MySqlConnection(connString);
            var command = connection.CreateCommand();
            try
            {
                connection.Open();
                if (nomeTxt.Text.Equals(null) || nomeTxt.Text.Equals(""))
                {
                    MessageBox.Show("Forne�a um nome para o jogo.");
                }
                else if (anoTxt.Text.Equals(null) || anoTxt.Text.Equals(""))
                {
                    MessageBox.Show("Forne�a um ano para o jogo.");
                }
                else
                {
                    command.CommandText = "INSERT INTO CadastroJogos (nome, ano) VALUES( '" + nomeTxt.Text + "','" + anoTxt.Text + "')";
                    command.ExecuteNonQuery();
                    MessageBox.Show("Cadastro de Jogo realizado com sucesso!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nao foi estabelecer conex�o. \n" + ex.Message);
            }
        
       finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                    connection.Close();
            }

}
    private void button2_Click(object sender, EventArgs e)
     {
            var connString = "Server=localhost;Database=jogos;Uid=root;Password=root";
            var connection = new MySqlConnection(connString);
            var command = connection.CreateCommand();

            try
            {
                connection.Open();
                if (!nomeTxt.Text.Equals(null) && !nomeTxt.Text.Equals(""))
                {
                    command.CommandText = "DELETE FROM CadastroJogos WHERE nome = '" + nomeTxt.Text + "'";
                    command.ExecuteNonQuery();
                    MessageBox.Show("Jogo Deletado.");
                }
                else if (!anoTxt.Text.Equals(null) && !anoTxt.Text.Equals(""))
                {
                    command.CommandText = "DELETE FROM CadastroJogos WHERE ano = '" + anoTxt.Text + "'";
                    command.ExecuteNonQuery();
                    MessageBox.Show("Jogo Deletado.");
                }
                else
                {
                    MessageBox.Show("Forne�a uma informa��o para a dele��o.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("N�o foi poss�vel estabelecer conex�o. \n" + ex.Message);
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                    connection.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var connString = "Server=localhost;Database=jogos;Uid=root;Password=root";
            var connection = new MySqlConnection(connString);
            var command = connection.CreateCommand();

            try
            {
                connection.Open();

                if (chaveAtualizaTB.Text.Length > 0)
                {
                    command.CommandText = "UPDATE CadastroJogos SET ano = '" + anoAtualizaTB.Text + "' WHERE nome LIKE '" + chaveAtualizaTB.Text + "'";
                    int rowAffected = command.ExecuteNonQuery();

                    if (rowAffected > 0)
                    {
                        MessageBox.Show ("Jogo Atualizado");
                    }
                    else
                    {
                        MessageBox.Show("Nenhum jogo foi atualizado.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show ("N�o foi poss�vel estabelecer a conex�o. \n" + ex.Message);
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                    connection.Close();
            }
        }
    }
    }
